To compile this map from Worldcraft, load in the .rmf file.  If you are only using the .map file, you will need to load the .map file into a text editor and set the wad paths (on line 3) to reflect your own settings.

autolycus
halflife.gamedesign.net