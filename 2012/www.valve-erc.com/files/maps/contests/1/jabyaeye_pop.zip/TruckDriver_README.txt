Title:   truckdriver.bsp
Author:  Jabyaeye
Date:    June 3, 2001 

This is an entry for the martyred pop machine contest hosted by the Valve ERC.
http://www.valve-erc.com/


The .bsp should be placed in the \valve\maps directory, and while in the console type "map truckdriver".

(for an alternate point-of-view, jump out of the truck once it is moving.) 



Special Thanks to: Mr. Yuk, Unquenque, Artbroken, Gonnas, and Delete_Me for their ideas and problem sorting.