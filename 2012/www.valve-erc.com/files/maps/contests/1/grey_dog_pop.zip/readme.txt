================================================================================
* LEVEL INFORMATION *
--------------------------------------------------------------------------------
TITLE                   : POPulation
FILENAME                : population.zip
.zip CONTENTS           : population.bsp, readme.txt
AUTHOR                  : Grey Dog
e-Mail                  : greydog98@hotmail.com
HOMEPAGE                : http://members.xoom.com/greydog98/
DATE                    : 05/29/2001
GAME PLAY TYPE          : SinglePlayer
--------------------------------------------------------------------------------
* LEVEL DESCRIPTION *
--------------------------------------------------------------------------------
A map created soley for entry into the Valve ERC map competiton concerning the
Martyred Popmachine mapping contest.

--------------------------------------------------------------------------------
SINGLE PLAYER           : 1 Player Respawn Points
CO-OPERATIVE            : No
DEATHMATCH              : No
DIFFICULTY SETTINGS ?   : No
NEW TEXTURES ?          : No
NEW SOUNDS ?            : No
CD TRACK #              : 0
--------------------------------------------------------------------------------
* CONSTRUCTION *
--------------------------------------------------------------------------------
BASE MAP USED ?         : No, New Map
PREFABS USED ?          : None
EDITORS USED            : Worldcraft 3.3 Registered,
UTILITIES USED          : None
KNOWN BUGS              : None
                       
COMPILE MACHINE         : AMD K6-2 300 with 64 megs of RAM
--------------------------------------------------------------------------------
* OTHER LEVELS BY THE AUTHOR *
--------------------------------------------------------------------------------
Half-Life                : Hour-Glass a Custom Game
Half-Life                : ADAM a Custom Game
--------------------------------------------------------------------------------
* SPECIAL INSTRUCTIONS OR INFORMATION *
--------------------------------------------------------------------------------
Copy the population.bsp into your Sierra/Half-Life/Valve/Maps directory and start
Half-Life using the commands hl.exe -console.  When the Half-Life game loads, select
Console from the menu options and then type, "map population" (without quote marks)
and then press your [ENTER] key.
 
--------------------------------------------------------------------------------
* COPYRIGHT/PERMISSIONS *
--------------------------------------------------------------------------------
Authors MAY NOT use this level as a base to build additional levels.

You MUST NOT distribute this level UNLESS you INCLUDE THIS FILE WITH
NO MODIFICATIONS. This LEVEL may be distributed ONLY over the Internet
and/or BBS systems You are NOT authorized to put this LEVEL on any CD or
distribute it in any way without my written permission.

 
[END OF DATA]=========================================================[.txt|Gen]

