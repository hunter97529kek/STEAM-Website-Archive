Here's my map for the contest, unzip as you would for HLDM.
No new models used.
No custom textures.
No headcrabs were hurt in this production.

This map may not be placed in any commercial ventures without this readme attached,... yadda, yadda, yadda.

Thanks to neo and NoodleHammer for testing it, and to my wife Kat for helping with the ending.

Enjoy!
Mr.Yuk
CEO Yuk Inc.
hicapclip@yahoo.com