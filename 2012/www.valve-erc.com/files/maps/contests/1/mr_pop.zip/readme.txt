Title: 		Overfeed
Filename: 	overfeed.bsp
Author: 		Iv�n S�nchez "MR"
URL:			www.alltheoffice.com
Email Address:		ivansanchez@wanadoo.es
 

==============================================================================
~* Play Information *~

Game:             Standard Half-Life
Single Player: 	Yes
Cooperative: 		No
Deathmatch: 		No
New Graphics: 		Just two custom textures, embedded into the .bsp . Two *very* crappy textures, i was unable to remip it with Wally.

~* Construction *~
 
Editor(s) used: 	Worldcraft 3.3, Zoner Half-Life tools 2.5.3, Photoshop 5.0, 
			Wally 1.51b

Computer Used: 		PII-300, 160mb Ram.
Compilation time: 	About 10 minutes
Construction time: 	Roughly 4-5 hours

==============================================================================


This map has been done specifically for the Valve-ERC "martyred pop machine". For details about that, visit www.valve-erc.com , and check out the "contests" section.

The objective of this map is to kill the imprisoned Garg.

You'll have to do it without any weapons. It's perfectly possible without any cheating, you only have to think a bit.

As per the contest rules, a pop machine plays an important role in this map.

Feel free to give me any feedback via email.


